# 10. Write a Python program to sum all the items in a dictionary.

dados = {1:2, 3:4, 5:6, 7:8, 9:10}

somatoria = sum(dados.values())

print("Somatoria:", somatoria)